package com.app.assessment

data class datahoroscope(
    val date: String,
    val horoscope: String,
    val sunsign: String
)